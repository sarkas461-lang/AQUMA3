package com.octagram.aquma

import android.app.Activity
import android.app.AlertDialog
import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 11, 13)
    private val panel = Color.rgb(17, 22, 25)
    private val cyan = Color.rgb(120, 232, 250)
    private val muted = Color.rgb(155, 169, 176)
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var eqEnabled = true
    private var bassEnabled = false
    private var virtualEnabled = false
    private var bandsContainer: LinearLayout? = null
    private var presetSpinner: Spinner? = null
    private var status: TextView? = null
    private var bassSeek: SeekBar? = null
    private var virtualSeek: SeekBar? = null
    private var gainSeek: SeekBar? = null
    private val frequencies = intArrayOf(32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    private val presets = listOf(
        "Flat", "QC", "Bas", "Klasik", "Metal", "Latin", "Pop", "Dance",
        "Rock", "Jazz", "Hip Hop", "Penguat Bass", "Penguat Treble",
        "Penguat Vokal", "Deep House"
    )
    private val curves = arrayOf(
        intArrayOf(0,0,0,0,0,0,0,0,0,0),
        intArrayOf(12,10,4,6,0,-1,2,6,6,10),
        intArrayOf(8,7,5,2,0,0,0,0,0,0),
        intArrayOf(4,3,0,2,-1,2,4,3,2,1),
        intArrayOf(5,4,2,0,-2,2,4,5,4,5),
        intArrayOf(4,2,0,2,3,3,2,1,2,3),
        intArrayOf(2,3,4,2,-1,-1,1,3,4,3),
        intArrayOf(5,4,1,0,-1,2,3,4,4,3),
        intArrayOf(5,4,2,0,-2,2,4,5,5,4),
        intArrayOf(3,2,0,2,-2,1,3,4,2,2),
        intArrayOf(5,4,2,0,-1,3,4,2,4,5),
        intArrayOf(8,7,5,3,1,0,0,0,0,0),
        intArrayOf(-2,-1,0,1,2,3,5,6,7,8),
        intArrayOf(-2,0,2,4,4,3,1,0,-1,-2),
        intArrayOf(6,4,1,0,-2,0,3,4,5,6)
    )
    private val currentLevels = IntArray(10)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        try {
            // Session 0 asks Android for a global output-mix effect when the device supports it.
            equalizer = Equalizer(0, 0)
            equalizer?.enabled = true
            bassBoost = BassBoost(0, 0)
            virtualizer = Virtualizer(0, 0)
            statusText("Efek audio berhasil dibuat. Dukungan audio global bergantung perangkat.")
        } catch (e: Exception) {
            statusText("Efek audio global tidak didukung perangkat ini. Kontrol mungkin tidak memengaruhi semua aplikasi.")
        }
        render()
    }

    private fun statusText(message: String) {
        status?.text = message
    }

    private fun render() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "AQUMA"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            letterSpacing = 0.12f
        }
        root.addView(brand)
        root.addView(label("A U D I O   E Q U A L I Z E R", 12f, cyan))
        root.addView(space(22))
        root.addView(label("System Audio", 22f, Color.WHITE, true))
        status = label("Memeriksa dukungan efek audio…", 13f, muted)
        root.addView(status)
        root.addView(space(12))

        val toggle = Button(this).apply {
            text = if (eqEnabled) "MATIKAN EQUALIZER" else "AKTIFKAN EQUALIZER"
            setTextColor(Color.BLACK)
            setBackgroundColor(cyan)
            setOnClickListener {
                eqEnabled = !eqEnabled
                try { equalizer?.enabled = eqEnabled } catch (_: Exception) {}
                text = if (eqEnabled) "MATIKAN EQUALIZER" else "AKTIFKAN EQUALIZER"
            }
        }
        root.addView(toggle, matchWrap())
        root.addView(space(20))
        root.addView(label("Preset", 18f, Color.WHITE, true))
        val spinner = Spinner(this)
        presetSpinner = spinner
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presets)
        spinner.setSelection(0)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                applyPreset(position)
            }
        }
        root.addView(spinner, matchWrap())
        root.addView(space(18))
        root.addView(label("EQUALIZER 10-BAND", 18f, Color.WHITE, true))
        root.addView(label("32 Hz  ·  64 Hz  ·  125 Hz  ·  250 Hz  ·  500 Hz  ·  1 kHz  ·  2 kHz  ·  4 kHz  ·  8 kHz  ·  16 kHz", 12f, muted))
        bandsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(panel, 12)
        }
        root.addView(bandsContainer, matchWrap())
        buildBandControls()
        root.addView(space(18))
        root.addView(label("BASS BOOST", 16f, Color.WHITE, true))
        bassSeek = SeekBar(this).apply {
            max = 1000
            progress = 0
            setOnSeekBarChangeListener(simpleSeek { v ->
                try {
                    val effect = bassBoost
                    if (effect != null && effect.strengthSupported) {
                        effect.setStrength(v.toShort())
                        effect.enabled = bassEnabled
                    }
                } catch (_: Exception) {}
            })
        }
        root.addView(bassSeek, matchWrap())
        root.addView(switchRow("Aktifkan Bass Boost", bassEnabled) { checked ->
            bassEnabled = checked
            try { bassBoost?.enabled = checked } catch (_: Exception) {}
        })
        root.addView(space(12))
        root.addView(label("VIRTUALIZER", 16f, Color.WHITE, true))
        virtualSeek = SeekBar(this).apply {
            max = 1000
            progress = 0
            setOnSeekBarChangeListener(simpleSeek { v ->
                try {
                    val effect = virtualizer
                    if (effect != null && effect.strengthSupported) {
                        effect.setStrength(v.toShort())
                        effect.enabled = virtualEnabled
                    }
                } catch (_: Exception) {}
            })
        }
        root.addView(virtualSeek, matchWrap())
        root.addView(switchRow("Aktifkan Virtualizer", virtualEnabled) { checked ->
            virtualEnabled = checked
            try { virtualizer?.enabled = checked } catch (_: Exception) {}
        })
        root.addView(space(12))
        root.addView(label("Pra-penguat", 16f, Color.WHITE, true))
        gainSeek = SeekBar(this).apply {
            max = 240
            progress = 120
        }
        root.addView(gainSeek, matchWrap())
        root.addView(label("Gain digital tambahan memerlukan jalur pemrosesan audio tersendiri.", 12f, muted))
        root.addView(space(16))
        val save = Button(this).apply {
            text = "SIMPAN PRESET SAAT INI"
            setOnClickListener { savePresetDialog() }
        }
        root.addView(save, matchWrap())
        val reset = Button(this).apply {
            text = "RESET KE FLAT"
            setOnClickListener {
                for (i in currentLevels.indices) currentLevels[i] = 0
                buildBandControls()
                applyPreset(0)
                presetSpinner?.setSelection(0)
            }
        }
        root.addView(reset, matchWrap())
        root.addView(space(12))
        root.addView(label("Catatan: Android tidak menjamin equalizer pihak ketiga memengaruhi YouTube atau semua aplikasi. Dukungan bergantung perangkat dan sesi audio. AQUMA tidak memakai iklan atau koneksi internet.", 12f, muted))
    }

    private fun buildBandControls() {
        val container = bandsContainer ?: return
        container.removeAllViews()
        for (i in frequencies.indices) {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val freq = TextView(this).apply {
                text = frequencyLabel(frequencies[i])
                setTextColor(Color.WHITE)
                textSize = 14f
            }
            line.addView(freq, LinearLayout.LayoutParams(0, dp(38), 1f))
            val value = TextView(this).apply {
                text = "${currentLevels[i]} dB"
                setTextColor(cyan)
                textSize = 14f
                gravity = Gravity.RIGHT
            }
            line.addView(value, LinearLayout.LayoutParams(dp(70), dp(38)))
            container.addView(line)
            val seek = SeekBar(this).apply {
                max = 240
                progress = (currentLevels[i] + 12) * 10
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                        val db = progress / 10 - 12
                        currentLevels[i] = db
                        value.text = "$db dB"
                        applyBand(i, db)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            container.addView(seek, matchWrap())
            container.addView(space(8))
        }
        if (equalizer == null) {
            val note = label("Efek equalizer belum tersedia pada output global perangkat ini.", 12f, muted)
            container.addView(note)
        }
    }

    private fun applyBand(uiIndex: Int, db: Int) {
        try {
            val eq = equalizer ?: return
            val count = eq.numberOfBands.toInt()
            if (count <= 0) return
            val targetHz = frequencies[uiIndex]
            var best = 0
            var bestDiff = Long.MAX_VALUE
            for (b in 0 until count) {
                val hz = eq.getCenterFreq(b.toShort()) / 1000
                val diff = kotlin.math.abs(hz.toLong() - targetHz.toLong())
                if (diff < bestDiff) { bestDiff = diff; best = b }
            }
            val range = eq.bandLevelRange
            val desired = (db * 100).coerceIn(range[0].toInt(), range[1].toInt()).toShort()
            eq.setBandLevel(best.toShort(), desired)
        } catch (_: Exception) {}
    }

    private fun applyPreset(index: Int) {
        if (index !in curves.indices) return
        for (i in currentLevels.indices) currentLevels[i] = curves[index][i]
        buildBandControls()
    }

    private fun savePresetDialog() {
        val text = EditText(this).apply { hint = "Nama preset" }
        AlertDialog.Builder(this)
            .setTitle("Simpan preset")
            .setView(text)
            .setPositiveButton("Simpan") { _, _ ->
                val name = text.text.toString().trim()
                if (name.isNotEmpty()) {
                    val prefs = getSharedPreferences("aquma_presets", MODE_PRIVATE)
                    prefs.edit().putString(name, currentLevels.joinToString(",")).apply()
                    Toast.makeText(this, "Preset \"$name\" disimpan di perangkat", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(label(text, 14f, Color.WHITE), LinearLayout.LayoutParams(0, dp(48), 1f))
        val sw = Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, value -> onChange(value) }
        }
        row.addView(sw)
        return row
    }

    private fun simpleSeek(action: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { action(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun frequencyLabel(hz: Int) = if (hz >= 1000) {
        val k = hz / 1000.0
        if (k == k.toInt().toDouble()) "${k.toInt()} kHz" else "$k kHz"
    } else "$hz Hz"

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), Color.rgb(40, 52, 58))
    }

    override fun onDestroy() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
