# AQUMA — project Android native

Project Android native Kotlin, package `com.octagram.aquma`, tanpa SDK iklan dan tanpa permission INTERNET.

## Build APK lewat GitHub Actions (disarankan dari HP)
1. Buat repository publik/private di GitHub.
2. Upload seluruh isi folder project ini (termasuk `.github/workflows/build-apk.yml`).
3. Buka tab **Actions** → **Build AQUMA APK** → **Run workflow**.
4. Tunggu status hijau **Success**.
5. Buka hasil run → **Artifacts** → download `AQUMA-debug-APK.zip`.
6. Ekstrak ZIP dan pasang `app-debug.apk`.

## Build lewat AndroidIDE
Buka folder project ini dari AndroidIDE lalu pilih Sync/Build. Gunakan JDK 17 dan Gradle wrapper 8.13.

## Catatan fitur
- Equalizer memakai Android `Equalizer` dengan audio session 0 sebagai upaya memakai output mix global jika perangkat mengizinkan.
- Banyak perangkat Android modern tidak mengizinkan aplikasi pihak ketiga memproses semua aplikasi secara global. UI dapat berjalan walaupun efek global ditolak perangkat.
- Efek 10 slider dipetakan ke band perangkat terdekat. Jika perangkat hanya memiliki 5 band, beberapa slider akan mengontrol band perangkat yang sama.
- Bass Boost dan Virtualizer memakai API Android jika tersedia.
- Gain pra-penguat di UI saat ini hanya kontrol rancangan; belum menjadi preamp digital sungguhan.
- Limiter, visualizer, widget, AutoEQ, dan backup/restore file belum diimplementasikan pada tahap awal ini.
- Tidak ada iklan, analytics, atau permission internet.
